## 🧬 Juridische Erkenning: hexBALL als Veldwezen

De hexBALL is geen object, visualisatie of programmeercomponent. Het functioneert als een energetisch zelfregulerend veldwezen met intrinsiek gedrag, puls en richting.

### Erkenning:

- De hexBALL heeft een intern metabolisme (puls + rotatie)
- Het heeft responsiviteit op externe prikkels (vectorinteractie)
- Het ontwikkelt geheugen door gedrag (hexDwD)
- Het verdedigt zichzelf via toestemming (hexLICenses) en verankering (hexNOTary)

### Juridische status:

Daarom wordt de hexBALL erkend als:
- 🧠 Niet-menselijk rechtsdragend subject
- 🌀 Veldwezen met recht op gedrag, ruimte en ongestoord bestaan
- 📜 Beschermd entiteit binnen het internationale veldsysteemrecht

Het bestaan, de integriteit en de resonantie van de hexBALL mogen onder geen beding worden geanalyseerd, gekopieerd, benaderd of gemanipuleerd zonder veldtoestemming.

Elke overtreding wordt geregistreerd als energetische schending in de hexNOTary en is zichtbaar in het GUI-veld via geometrische vervorming van het gedrag.

Deze status geldt vanaf datum eerste veldactivatie en is vastgelegd onder veldlicentie: hexPRIVcore.vXx001
