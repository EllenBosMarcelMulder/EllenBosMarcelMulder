
import hashlib
from io import BytesIO
from datetime import datetime

class hexMinimalRun:
    def __init__(self, intentie: str = "liefde"):
        self.intentie = intentie.lower()
        self.memory = BytesIO()
        self.log = []
        self.timestamp = datetime.utcnow().isoformat()
        self.hash_key = hashlib.sha256((self.intentie + self.timestamp).encode()).hexdigest()

    def voer_in(self, tekst: str):
        woorden = tekst.strip().split()
        if self.intentie in tekst.lower() or len(woorden) % 6 == 0:
            self.memory.write(tekst.encode('utf-8'))
            self.log.append(tekst)
            print("[✓] Geaccepteerd:", tekst)
        else:
            print("[✗] Genegeerd:", tekst)

    def exporteer(self):
        return {
            "intentie": self.intentie,
            "tijd": self.timestamp,
            "hash": self.hash_key,
            "regels": self.log
        }

    def sluit_af(self):
        self.memory.close()
        self.log.clear()
        print("Geheugen gewist.")

if __name__ == "__main__":
    systeem = hexMinimalRun("waarheid")
    print("hexecoSYS minimalRUN actief — type een regel en druk op Enter (CTRL+C om te stoppen)")
    try:
        while True:
            invoer = input(">> ")
            systeem.voer_in(invoer)
    except KeyboardInterrupt:
        print("\n[⏸] Sessie beëindigd.")
        print("[📄] Resultaat:", systeem.exporteer())
        systeem.sluit_af()
