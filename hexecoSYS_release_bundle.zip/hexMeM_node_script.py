
import hashlib
import tempfile
from datetime import datetime
from io import BytesIO

class hexMeM:
    def __init__(self, node_intent: str):
        self.intent = node_intent.strip().lower()
        self.session_memory = BytesIO()
        self.timestamp = datetime.utcnow().isoformat()
        self.hash_key = hashlib.sha256((self.intent + self.timestamp).encode()).hexdigest()
        self.resonant_log = []

    def write(self, data: str):
        if self._resonates(data):
            encoded = data.encode('utf-8')
            self.session_memory.write(encoded)
            self.resonant_log.append(data)

    def _resonates(self, data: str) -> bool:
        return self.intent in data.lower() or len(data.strip().split()) % 6 == 0

    def close(self):
        self.session_memory.close()
        self.resonant_log.clear()

    def export_summary(self):
        return {
            "node_intent": self.intent,
            "session_time": self.timestamp,
            "hash_key": self.hash_key,
            "resonant_lines": self.resonant_log
        }

if __name__ == "__main__":
    mem = hexMeM("liefde")
    inputs = [
        "Dit is een veldzin met ritme en waarheid.",
        "Onbelangrijke testregel.",
        "Liefde stroomt hier doorheen met zes woorden.",
        "Nog een irrelevante zin zonder waarde.",
        "Zuivere nodezin raakt het hart in stilte."
    ]
    for line in inputs:
        mem.write(line)
    print(mem.export_summary())
    mem.close()
